﻿using StreamingAPI.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace StreamingAPI.DAL
{
    public class DataAccess
    {
        DataTable dt=new DataTable();
        SqlDataAdapter da;
        
        public IEnumerable<Student> getAllStudent()
        {
            try
            {
                using (SqlConnection connection = getSQLConnection())
                {
                    da = new SqlDataAdapter("select * from Student", connection);
                    da.Fill(dt);

                }
            }
            catch (Exception ex)
            { 
                //Log error 
            }
            
            var listStudent = Utility.ConvertToList<Student>(dt);
            return listStudent;
        }


        
        public async Task<List<Student>> GetAllStudentByStreaming()
        {

            List<Student> students = new List<Student>();
            var studentcollection = getAllStudentUsingReader();
            await foreach (var student in studentcollection)
            {
                students.Add(student);
            }
            
            return students;

        }


        public async IAsyncEnumerable<Student> getAllStudentUsingReader()
        {
            Student objStd = new Student();
                using (SqlConnection connection = getSQLConnection())
                {
                    SqlCommand command = new SqlCommand("select * from Student", connection);
                    await command.Connection.OpenAsync().ConfigureAwait(false);
                    command.ExecuteNonQuery();
                    SqlDataReader reader = await command.ExecuteReaderAsync().ConfigureAwait(false);

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            objStd.id= (long)reader["id"];
                            objStd.code = (string)reader["code"];
                            objStd.name = (string)reader["name"];
                            objStd.address = (string)reader["address"];
                            yield return objStd;
                        }
                    }
                    
                    else
                    {
                        Console.WriteLine("No rows found.");
                    }
                    reader.Close();

                }
            
        }

        internal SqlConnection getSQLConnection()
        {
            return new SqlConnection(Utility.connectionString);
        }




    }
}
