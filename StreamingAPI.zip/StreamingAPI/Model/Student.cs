﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StreamingAPI.Model
{
    public class Student : IStudent
    {
        public Int64 id { get; set; }

        public string code { get; set; }

        public string name { get; set; }

        public string remarks { get; set; } 

        public string address { get; set; }
    }
}
