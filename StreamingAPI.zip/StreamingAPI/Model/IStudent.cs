﻿namespace StreamingAPI.Model
{
    public interface IStudent
    {
    }
}